'use client';

import { useState } from 'react';

const nav = [
  ['Overview', '◫'], ['Research library', '⌕'], ['Content studio', '▧'],
  ['Approval centre', '✓'], ['Publishing calendar', '▦'], ['Brand settings', '⚙']
];

export default function Home() {
  const [active, setActive] = useState('Overview');
  const [command, setCommand] = useState('');
  const [submitted, setSubmitted] = useState(false);

  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">TI</div>
          <div><div className="brand-name">Travel Intelligence</div><div className="brand-sub">LOCAL DISCOVERY JOURNAL</div></div>
        </div>
        <div className="workspace-label">WORKSPACE</div>
        <nav>{nav.map(([label, icon]) => <button key={label} className={`nav-item ${active === label ? 'active' : ''}`} onClick={() => setActive(label)}><span className="nav-icon">{icon}</span>{label}{label === 'Approval centre' && <span className="nav-count">0</span>}</button>)}</nav>
        <div className="sidebar-bottom">
          <div className="profile-dot">TI</div>
          <div><strong>Editorial workspace</strong><small>Personal account</small></div>
          <span className="status-dot" />
        </div>
      </aside>

      <section className="main">
        <header className="topbar">
          <div className="crumb">Workspace <span>/</span> {active}</div>
          <div className="top-actions"><span className="location-pill">⌖ &nbsp; North Paravur · 20 km</span><div className="avatar">TI</div></div>
        </header>

        <div className="content">
          <div className="eyebrow">YOUR LOCAL TRAVEL DESK <span>•</span> KERALA, INDIA</div>
          <div className="hero-row">
            <div><h1>{active === 'Overview' ? <>Discover closer.<br/><em>Tell better stories.</em></> : active}</h1>
              <p className="intro">A thoughtful research and editorial studio for places worth discovering.</p></div>
            <div className="date-note"><span className="tiny-label">CURRENT EDITION</span><strong>North Paravur</strong><small>20 kilometre discovery radius</small></div>
          </div>

          <section className="command-card">
            <div className="card-kicker">01 / GIVE YOUR AGENT A BRIEF</div>
            <label htmlFor="command">What should we discover today?</label>
            <textarea id="command" value={command} onChange={e => {setCommand(e.target.value); setSubmitted(false);}} placeholder="e.g. Find quiet backwater experiences and lesser-known heritage places within 20 km of North Paravur. Suggest three carousel stories." />
            <div className="command-footer"><span>Research first. Every fact should have a source.</span><button className="primary-button" disabled={!command.trim()} onClick={() => setSubmitted(true)}>Create research brief <span>↗</span></button></div>
            {submitted && <div className="notice">Brief captured in this interface preview. Research execution will be connected in the next milestone.</div>}
          </section>

          <div className="section-heading"><div><div className="card-kicker">02 / YOUR WORKSPACE</div><h2>Editorial overview</h2></div><span className="muted">First edition · Local discovery</span></div>
          <div className="stats-grid">
            <article className="stat-card"><span className="stat-label">RESEARCH REPORTS</span><strong>—</strong><small>Awaiting first research run</small></article>
            <article className="stat-card"><span className="stat-label">CONTENT DRAFTS</span><strong>—</strong><small>No drafts created yet</small></article>
            <article className="stat-card"><span className="stat-label">AWAITING APPROVAL</span><strong>0</strong><small>Nothing publishes automatically</small></article>
          </div>

          <div className="lower-grid">
            <section className="panel">
              <div className="panel-head"><div><div className="card-kicker">03 / FIRST FIELD NOTE</div><h3>Cherai Beach</h3></div><span className="tag">STARTER DESTINATION</span></div>
              <div className="destination-art"><div className="sun" /><div className="horizon" /><div className="sea" /><div className="sand" /><div className="art-caption">THE COASTAL JOURNAL <span>01</span></div></div>
              <p className="panel-copy">Our first test destination for the research-to-carousel workflow. No facts or visitor details are pre-filled; the research agent will source and verify them.</p>
              <div className="panel-foot"><span>Research status</span><strong>Not started</strong></div>
            </section>
            <section className="panel">
              <div className="panel-head"><div><div className="card-kicker">04 / EDITORIAL PIPELINE</div><h3>From discovery to post</h3></div></div>
              <div className="pipeline">
                {['Destination research','Source verification','Story & carousel draft','Your review and approval','Instagram publishing'].map((item, i) => <div className="pipeline-row" key={item}><span className="pipeline-num">0{i+1}</span><span>{item}</span><span className={i===3?'approval-dot':'step-dot'}>{i===3?'●':'○'}</span></div>)}
              </div>
              <div className="safety-note"><span>✳</span><div><strong>Your approval stays in control</strong><small>Publishing will remain disabled until you approve a complete post.</small></div></div>
            </section>
          </div>
          <footer>TRAVEL INTELLIGENCE <span>·</span> AN EDITORIAL DISCOVERY WORKSPACE</footer>
        </div>
      </section>
    </main>
  );
}
