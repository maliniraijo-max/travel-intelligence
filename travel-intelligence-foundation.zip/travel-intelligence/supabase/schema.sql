-- Travel Intelligence: initial database blueprint
-- Apply in a new Supabase project after reviewing the schema.
create extension if not exists pgcrypto;

create table if not exists public.destinations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique,
  category text,
  description text,
  latitude double precision,
  longitude double precision,
  locality text,
  country text default 'India',
  created_at timestamptz not null default now()
);

create table if not exists public.research_reports (
  id uuid primary key default gen_random_uuid(),
  destination_id uuid references public.destinations(id) on delete set null,
  title text not null,
  brief text,
  findings jsonb not null default '[]'::jsonb,
  status text not null default 'draft' check (status in ('draft','researching','ready','archived')),
  created_at timestamptz not null default now()
);

create table if not exists public.research_sources (
  id uuid primary key default gen_random_uuid(),
  report_id uuid not null references public.research_reports(id) on delete cascade,
  title text,
  url text not null,
  publisher text,
  accessed_at timestamptz not null default now(),
  notes text
);

create table if not exists public.content_projects (
  id uuid primary key default gen_random_uuid(),
  report_id uuid references public.research_reports(id) on delete set null,
  title text not null,
  format text not null default 'carousel',
  caption text,
  hashtags text[] not null default '{}',
  status text not null default 'draft' check (status in ('draft','in_review','approved','rejected','scheduled','publishing','published','failed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.carousel_slides (
  id uuid primary key default gen_random_uuid(),
  content_project_id uuid not null references public.content_projects(id) on delete cascade,
  slide_number integer not null,
  headline text,
  body text,
  image_path text,
  image_alt text,
  unique(content_project_id, slide_number)
);

create table if not exists public.approval_history (
  id uuid primary key default gen_random_uuid(),
  content_project_id uuid not null references public.content_projects(id) on delete cascade,
  decision text not null check (decision in ('approved','rejected','revision_requested')),
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.publishing_queue (
  id uuid primary key default gen_random_uuid(),
  content_project_id uuid not null unique references public.content_projects(id) on delete cascade,
  scheduled_for timestamptz,
  status text not null default 'queued' check (status in ('queued','processing','published','failed','cancelled')),
  instagram_media_id text,
  published_at timestamptz,
  error_message text,
  created_at timestamptz not null default now()
);

-- IMPORTANT: Do not expose service-role credentials in client code.
-- Enable RLS and add owner-scoped policies before connecting authentication.
